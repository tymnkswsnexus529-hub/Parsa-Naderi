<?php
// Parsa Naderi website API - PHP 7.4+
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') { http_response_code(204); exit; }

$base = __DIR__;
$storage = $base . DIRECTORY_SEPARATOR . 'storage';
$uploads = $base . DIRECTORY_SEPARATOR . 'uploads';
foreach ([$storage, $uploads] as $dir) { if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) { http_response_code(500); exit('Storage unavailable'); } }
$storeFile = $storage . '/data.json';
$passFile = $storage . '/admin.hash';
if (session_status() !== PHP_SESSION_ACTIVE) {
  $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
  session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
  session_start();
}
function out(array $v, int $status=200): void { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode($v, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
function body_json(): array { $raw=file_get_contents('php://input'); $v=json_decode($raw ?: '', true); if (!is_array($v)) out(['ok'=>false,'error'=>'Invalid JSON'],400); return $v; }
function require_admin(): void { if (empty($_SESSION['admin'])) out(['ok'=>false,'error'=>'ورود مدیر لازم است'],401); }
function load_data(string $file): array { if (!is_file($file)) return ['ts'=>1,'site'=>[],'projects'=>[],'files'=>[]]; $v=json_decode((string)file_get_contents($file),true); return is_array($v)?$v:['ts'=>1,'site'=>[],'projects'=>[],'files'=>[]]; }
function write_data(string $file, array $data): bool { $data['ts']=max((int)($data['ts']??0),time()*1000); $json=json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); if ($json===false) return false; $tmp=$file.'.tmp'; if (file_put_contents($tmp,$json,LOCK_EX)===false) return false; return rename($tmp,$file); }
if (!is_file($storeFile) && is_file($base.'/data.json')) { @copy($base.'/data.json',$storeFile); }
$action=(string)($_GET['a']??'');
if ($action==='get' && $_SERVER['REQUEST_METHOD']==='GET') { out(['ok'=>true,'data'=>load_data($storeFile),'admin'=>!empty($_SESSION['admin']),'counts'=>[]]); }
if ($action==='login' && $_SERVER['REQUEST_METHOD']==='POST') {
  $b=body_json(); $pw=(string)($b['pw']??'');
  if (!isset($_SESSION['tries'])) $_SESSION['tries']=0;
  if ($_SESSION['tries']>=10) out(['ok'=>false,'error'=>'تعداد تلاش زیاد است؛ بعداً دوباره امتحان کنید'],429);
  if (is_file($passFile)) $valid=password_verify($pw,(string)file_get_contents($passFile));
  else { $configured=getenv('PANEL_PASSWORD'); if ($configured===false || $configured==='') $configured='1392p'; $valid=hash_equals($configured,$pw); }
  if (!$valid) { $_SESSION['tries']++; out(['ok'=>false,'error'=>'رمز نادرست است'],401); }
  session_regenerate_id(true); $_SESSION['admin']=true; $_SESSION['tries']=0; out(['ok'=>true]);
}
if ($action==='logout' && $_SERVER['REQUEST_METHOD']==='POST') { $_SESSION=[]; session_destroy(); out(['ok'=>true]); }
if ($action==='save' && $_SERVER['REQUEST_METHOD']==='POST') { require_admin(); $data=body_json(); if (!isset($data['site']) || !isset($data['projects']) || !is_array($data['projects'])) out(['ok'=>false,'error'=>'ساختار داده نامعتبر است'],400); if (!write_data($storeFile,$data)) out(['ok'=>false,'error'=>'ذخیره روی سرور ناموفق بود'],500); out(['ok'=>true,'ts'=>$data['ts']??time()*1000]); }
if ($action==='setpw' && $_SERVER['REQUEST_METHOD']==='POST') { require_admin(); $b=body_json(); $pw=(string)($b['pw']??''); if (strlen($pw)<8) out(['ok'=>false,'error'=>'رمز باید حداقل ۸ نویسه باشد'],400); if (file_put_contents($passFile,password_hash($pw,PASSWORD_DEFAULT),LOCK_EX)===false) out(['ok'=>false],500); out(['ok'=>true]); }
if ($action==='upload' && $_SERVER['REQUEST_METHOD']==='POST') {
  require_admin();
  $id=(string)($_POST['id']??''); $idx=filter_var($_POST['idx']??null,FILTER_VALIDATE_INT); $total=filter_var($_POST['total']??null,FILTER_VALIDATE_INT); $kind=(string)($_POST['kind']??'');
  if (!preg_match('/^[a-zA-Z0-9_-]{6,100}$/',$id) || $idx===false || $total===false || $total<1 || $total>220 || $idx<0 || $idx>=$total || !in_array($kind,['apk','img','file'],true) || empty($_FILES['f']['tmp_name'])) out(['ok'=>false,'error'=>'اطلاعات بارگذاری نامعتبر است'],400);
  $dir=$storage.'/chunks_'.$id; if (!is_dir($dir) && !mkdir($dir,0700,true)) out(['ok'=>false],500);
  $part=$dir.'/'.$idx.'.part'; if (!move_uploaded_file($_FILES['f']['tmp_name'],$part)) out(['ok'=>false,'error'=>'دریافت بخش فایل ناموفق بود'],500);
  if ($idx < $total-1) out(['ok'=>true,'part'=>$idx]);
  $ext=$kind==='apk'?'apk':($kind==='img'?'jpg':'bin'); $name=bin2hex(random_bytes(16)).'.'.$ext; $dest=$uploads.'/'.$name; $out=fopen($dest,'wb'); if (!$out) out(['ok'=>false],500);
  $size=0; for($i=0;$i<$total;$i++){ $p=$dir.'/'.$i.'.part'; if(!is_file($p)){fclose($out);@unlink($dest);out(['ok'=>false,'error'=>'یکی از بخش‌های فایل نرسیده است'],400);} $in=fopen($p,'rb'); $size+=stream_copy_to_stream($in,$out); fclose($in); }
  fclose($out); foreach(glob($dir.'/*')?:[] as $p) @unlink($p); @rmdir($dir);
  @chmod($dest,0644); out(['ok'=>true,'url'=>'uploads/'.$name,'size'=>$size]);
}
if ($action==='delfile' && $_SERVER['REQUEST_METHOD']==='POST') { require_admin(); $b=body_json(); $name=basename((string)($b['name']??'')); if ($name!=='' && preg_match('/^[a-f0-9]{32}\.(apk|jpg|bin)$/',$name)) { $p=$uploads.'/'.$name; if(is_file($p)) @unlink($p); } out(['ok'=>true]); }
out(['ok'=>false,'error'=>'Unknown action'],404);
?>